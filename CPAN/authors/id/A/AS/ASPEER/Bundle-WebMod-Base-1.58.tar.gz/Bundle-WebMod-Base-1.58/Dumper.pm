$VAR1 = [
  {
    'WebMod::Base' => '1.8',
    'WebMod::Constant' => '1.15',
    'WebMod::Debug' => '1.28',
    'WebMod::Err' => '1.25',
    'WebMod::Log' => '1.16',
    'WebMod::Proto' => '1.9'
  },
  {
    'A/AS/ASPEER/WebMod-Base-1.8.tar.gz' => [
      'WebMod::Base'
    ],
    'A/AS/ASPEER/WebMod-Constant-1.15.tar.gz' => [
      'WebMod::Constant'
    ],
    'A/AS/ASPEER/WebMod-Debug-1.28.tar.gz' => [
      'WebMod::Debug'
    ],
    'A/AS/ASPEER/WebMod-Err-1.25.tar.gz' => [
      'WebMod::Err'
    ],
    'A/AS/ASPEER/WebMod-Log-1.16.tar.gz' => [
      'WebMod::Log'
    ],
    'A/AS/ASPEER/WebMod-Proto-1.9.tar.gz' => [
      'WebMod::Proto'
    ]
  },
  [
    'WebMod::Base',
    'WebMod::Err',
    'WebMod::Debug',
    'WebMod::Log',
    'WebMod::Constant',
    'WebMod::Proto'
  ]
];
